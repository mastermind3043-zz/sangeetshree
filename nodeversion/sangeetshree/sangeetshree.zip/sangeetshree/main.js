(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".fill-remaining-space {\r\n\tflex: 1 1 auto;\r\n}\r\n\r\n.hindi-title {\r\n\tpadding-left: 20px;\r\n    font-family: khand;\r\n    font-style: italic;\r\n    font-weight: bold;\r\n    font-size: 80px;\r\n}\r\n\r\n.header-logo {\r\n  background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAAOwwAADsMBx2+oZAAACrZJREFUeNrt3GmQXNV1wPHf6+6ZnlUzGg1a0DpaEJKQiTC2jAUR2IDB5RBMoGJIIBCXMSZ2bIMRYOxyXHZRLmKUuMoYVyB4IaCw2CyWETsmgBxwGYgka5CEkNCKkEYjMatmuvvlwxuIEEJqtaanZ8j7f+mu7vfuPfece98999xzHzExMTExMTExMTExMTExMTEx/18ISi1AoSzEbpIfo6yaHuT+vNRCFcCQNMBidFM9mjMb+WjIg1tZWk/uuFILd4ikSi1AIcxAlqnVXF3OrF5q07yYorPUsh0qQ9IA9dFHJUahMk1deoiO5kSpBThMwn0+hxxD3QBDntgAJSY2QImJDVBiPigGGJIeEEPfAO8ofqi6QUVdB9yHLJWVjKliTyNb95A7/jDL3YBeWo7gf9LYzZ82kantB5nvwnbKz6Chg8xydlaRO6eYiioGX4o+Es9y1mae2sg9Szkewc2HWfY/4ypS9zDnYc6+lTFw9WGWuwS3Ufk8F2zhkfXc8muObMOIkmqzAK7CJMpe5ooW2nfQuYY7FnF0iPNKLeA+fB8zSP0Xn93MshZy23jxN8wKMatI9RZtDjgS6+jt5ZkuXg5I13PWTD5/Gw3nF6viAngK38IdfGQKV1RwTEhHO0+Xs2kVakotZCF8B9OjXnX2Zpa3kHuDLcu5bBHpR0otIH6OP2IJ4zbzny1kd9D5Knf9qm+0zihi/UWdhL+LJ8hs47GRjE7y9TImljO/lntT7Clm/fkwQuRBpZkQRk+asIvftbLwOlbtQXMR608Wu4G/QE/0KGruoa2Ljje4ZzkrMmTvL7YAB2E6yrCK9nFUJOh8g39ZydLPEf5lkesfsAXMg8hEDax6grdGkfnWQFV+ECbjNfyammlULqF1PJnBNE/FxHwwGfQxlM+gmcS/Ud5A2e9prGL4aIZVkkqT7CTTzp4WdufYeiwdi8jcSG9gcIcpBq0B1hA8SfWpTGllWh0n1jOqmyOzNCapCkgFJHJkQ3pD2st5vZc3t/F6lj+08OpDbHqS7hNxS6kbtg+DygCL8Cblsxg3iVMqmJ1ifioKNYwI+tzmt4Xeu2fv/VtIGNKbY0cna3t5ZgdLd/P8P7DzZHK3lbqx+8hdUh7HLlITmT6MT9bwF+X8WYLhotX6YckZ0pNlYwd/7OCh7Tz5CTZ9k/D6Ere96OuAA3EN6kjMo2kS547kqhrOL2N6EK3+D1v5ogKSCRoqmFnNyTVMOYfWNlqX0L0Mr5RIByUbAS8jR0WOkxu5vIYTAhoMzB5Fzx7WtXDfG/zsZl6bQ+bbJdDDgI+An4gy2x7kiKO5eBTXVDA3oNbAdYhkisZqZlUzcwo772f935J7aoD18a4Gfx05ypPUtdKdouMWcuOwqR8q+yUuxGM0jeMrjVyQjJKrSkmukz9s5ochj1TQdqdoz+Fw+ZpofvsiqQ3Ut9DzEm2jCB/uu+YdAyzEb0lcw+lj+btyurpZtoUX2lh9O2/dR0+hXfQ2XIJHmTyRKxo4Pxk9cgYD2V7WtHNTK78op+3YAgs6HatIfJXqzzBsGzPGMbeHGV1sXMHNw9mwBV+wVzT0KFRRNopTRnJuQDJLdyMb2lj5PZ5fRfOdNHey6Vd0zyBcmIdQP8XFkfKbBqHyIVnGtBq+EpJbx8+fp3Nunje/jjUkK6jayZSpzM7xsTpm10VR4AkJ0r1sq+C5MjZM7Lv3nQ79bdxA4nHObOIf03w4QRUq+i7pztDew5pOnt/OA8NYmqV3zgGEm4JX8R+M+QjXNkSPncG6w5froXkt372R+0+gd8EBLl6MHHpomMJnj+QTPUxLMzUZeXFlENLdw7ZuntzMD2pZ/SrOtc8cEEaKSo1j8lSO3c0xdXy8jKYk45KUI8hF4eXHe/l8wNbxBxDyOXRSNY7LR7AgyRGl1vLBjPAWzzXzjTN54SZ8+X0ubBYpJMOnh/HjcpqCyCjZLB3Y0MW6Np7dzQsvsOI3tJxKeF1fGe/akOmzRqaW1W2svorFZzG8g+nT+WiWD6WZXUlDwMYMXQdyox7ArSQWcFojX0wMfuVDopa5R/Gle9l8Gpvf78LtoqHcya5atoeUtbOpl9/v4pVWXq7gtRvZdQaZK/ru29vTOuic+jPR8/ufSITUn8n4Chqxag6bvmD/8ZUqrMdWmkbwo0rO0DckhwJZtm/mht/y44l0X7ifa67GcVhLxaeYlaZ2B1vuZuObdN+bRxywaH73Ymyh4hSubGABhpVMmwXSxYsr+erpPHs9vlmEOoqyEFuIi9DN7NFcmaTJIIk7HQpJGkL2jOW/x9L9QBHqKMqyfxS+R80I/ros2ugecsqHBOkGPnUcH74ElxWhjqKMgLtQw4yRLEgx/rALLCFJ6lK0jOGZuWTu7ufy+3UEfAh34lJSlZxUzoQB01SRSJCqZ948jpohyvjr5/L7j9MxEnMZW8ung3fO0w1t0hzTyLxZJDr6uex+NcCXRX7xHKaVc8yAaajIJKipZP49DP9c/5fdf9yIOQTDo+y3uoFTUfGpZVY5Y0/Sl4rdT/SrAU7Aj6jtieL7VQOqoeIzMtU3p13Uj4X2qwFOxKmR+zndED0E/n4EVI9j8l+ROKkfy+03A4wW+ZvraRwiMZ9DIkVlHU0NlLX1Y7n9ZoC3gzwd1Oc+IN7PPgS9jM1Q0dKPhe73MXEdXiK4krrZVOezWguwFWOYHJAutbaKQcDIC5l6PFvPz2N1H2IDmdXsrqD77P2X+W6uxzfQzOwarqyLUkTyJsuwBNOCIRT5zJccrViboFee4ZV2drZxX8gdAV37+ubvGQGviDRXz3E1nCPKVsibkiYaFZm+RLFDOuRZQ1hJdS8PBXTt+/97DDAT7djOqjKeTkcT6mDObx3UZMm281gnb+2vc75nGF0hWsKupewSGhpIxdovjABdhCvZdSqdQzIkHBMTExNTNAqeF44XvaLwSNJJkuEQ8JS2kF0RvWP0PcxDG4kxpPNpSIAOwj/RU0NuY4EyFWSAJ0T+fpYJ1ZxXNjS2HQO8meSh13l5NOFcUdrNfHSRLuf0tyJbVDp4hwpCult49H6enkSmkJeFFBSxnNp3Y47j01G228hSafVQCOnaReW9NJ9MN2wR5S9tYvwpXNYQbezlq5fcCI66kGXpKE/rkCnIAG2iYE+GXVg3ROLOQUhrD9sT0RkyRO8eOhUJWgPW97AN1fJ4pIZ097Kxp+80ZkFCFXLTImSir5VJji4vfY5/Xm0N6RzOigtoedr/vYRjN4YRPMeEncwuy8MAIbpob2Hlpbx+EeEvS93CmJiYmJiYmPwZ0AjpJFHu0O8ov5g5k6Ks6YLoIbuc1xazbAy914q8s/Uk5jNjMrPK8tzzbqHjWV76ezZ9Df86gDoZUBf+KNEWWwczjuAG0fmGgkIYKcIpPPo3XF7G9mtxNKYwqZHvpDhNnht0tbTP5Ief5KbGAX6N2oAa4O3uWE0iGR3YqFKgAQLUUFdF8u1h3NeYdCo6QlUlPwMEKRJHUNMkGqUDyYAa4GHcjdd4ZRrfH3sY+aMZsttY2syO+r7f1qGVtTO5fgIfT+U5AtrYvZolt7Dn9oFUiBIdnFiDboLRBIUkJgVowa3kpuDSvf67HVsIziOol9/wWkn474RNoldtxsTExMTExMTExMTExMTExMTExHwA+V8QfeGdy3KxvwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOC0wOC0wM1QwMzowNTowNCswMDowMEz/UyEAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTgtMDgtMDNUMDM6MDU6MDQrMDA6MDA9ouudAAAARnRFWHRzb2Z0d2FyZQBJbWFnZU1hZ2ljayA2LjcuOC05IDIwMTQtMDUtMTIgUTE2IGh0dHA6Ly93d3cuaW1hZ2VtYWdpY2sub3Jn3IbtAAAAABh0RVh0VGh1bWI6OkRvY3VtZW50OjpQYWdlcwAxp/+7LwAAABh0RVh0VGh1bWI6OkltYWdlOjpoZWlnaHQAMTkyDwByhQAAABd0RVh0VGh1bWI6OkltYWdlOjpXaWR0aAAxOTLTrCEIAAAAGXRFWHRUaHVtYjo6TWltZXR5cGUAaW1hZ2UvcG5nP7JWTgAAABd0RVh0VGh1bWI6Ok1UaW1lADE1MzMyNjU1MDRwFfyzAAAAD3RFWHRUaHVtYjo6U2l6ZQAwQkKUoj7sAAAAVnRFWHRUaHVtYjo6VVJJAGZpbGU6Ly8vbW50bG9nL2Zhdmljb25zLzIwMTgtMDgtMDMvZGVjNjlhMTM5YWY3ZDQxNzMyMTI2MjM3YTUwYTEzMjMuaWNvLnBuZx0c9qEAAAAASUVORK5CYII=');\r\n  background-size: cover;\r\n  min-width: 96px;\r\n  min-height: 96px;\r\n}"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card>\n<mat-card-header>\n    <div mat-card-avatar class=\"header-logo\"></div>\n    <mat-card-title class=\"hindi-title\">संगीतश्री</mat-card-title>\n    <mat-card-subtitle style=\"font-size: 20px;\">School of Music - Hindustani Classical Vocal</mat-card-subtitle>\n  </mat-card-header>\n\n<mat-card-content>\n  <mat-card>\n    <img mat-card-image src=\"../assets/hindustani.png\" alt=\"SangeetShree\">\n  </mat-card>\n  <br><br>\n  <mat-card>\n    <mat-card-title>About</mat-card-title>\n    <mat-card-content>\n      Sangeetshree is a humble school of Hindustani Classical Music which has begun recently in the city of Hyderabad. This school teaches the Kirana Gayaki style of Hindustani Classical Music. The school is an initiative of Mrs. Bina Sen, who is an M.A holder in Hindustani Classical Music. She has been associated with music for close to forty years and is a student of <a href= 'https://en.wikipedia.org/wiki/Sipra_Bose'>Bidushi.Sipra Bose</a>. She has been a teacher for a very long time in Tata, Jamshedpur and has recently moved to Hyderabad and has started the school in the city.\n    </mat-card-content>\n  </mat-card>\n  <br><br>\n  <mat-card>\n    <mat-card-title>Kirana Gharana</mat-card-title>\n    <mat-card-content>\n      Kirana Gharana is one of the most prolific Hindustani khyal gharanas and is concerned foremost with perfect intonation of notes (swara). The central concern of the Kirana style is swara, or individual notes, in particular precise tuning and expression of notes. In the Kirana Gayaki, the individual notes (swaras) of the raga are considered not just random points in the scale but independent realms of music capable of horizontal expansion. Highly emotional pukars in the higher octaves form a part of the musical experience. Another unique feature of this gharana is the highly intricate and ornate use of the sargam taan (weaving patterns with the notations themselves) introduced by Abdul Karim Khan under influence from the Carnatic classical style.\n    </mat-card-content>\n  </mat-card>\n  <br><br>\n  <mat-card>\n    <mat-card-title>Showcase</mat-card-title>\n    <mat-card-content>\n      <mat-card>\n        <mat-card-title><img style=\"max-height:40px;\" src=\"../assets/yt.png\"/></mat-card-title>\n        <mat-card-content>\n          <iframe width=\"100%\" height=\"315\" src=\"https://www.youtube.com/embed/videoseries?list=PLWLKA0GlfnUiFUXx_kfk0rmQCSixL3YrV\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>\n        </mat-card-content>\n      </mat-card>\n      <br>\n      <br>\n       <mat-card>\n        <mat-card-title><img style=\"max-height:60px;\" src=\"../assets/sc.png\"/></mat-card-title>\n        <mat-card-content>\n          <iframe width=\"100%\" height=\"400\" scrolling=\"no\" frameborder=\"no\" src=\"https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/users/151016797&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true\"></iframe>\n        </mat-card-content>\n      </mat-card>\n    </mat-card-content>\n  </mat-card>\n  <br><br>\n  <mat-card>\n      <mat-card-title>Get in touch</mat-card-title>\n       <mat-card-content>\n        <mat-grid-list cols=\"3\" rowHeight=\"200px\">\n  <mat-grid-tile\n      [colspan]=\"1\"\n      [rowspan]=\"1\">\n    <span><strong>Mrs. Bina Sen</strong><br/>C2-701, Power Welfare Society 7 Hills,<br/>Kokapet, Hyderabad - 500075<br/><a href=\"tel:+918142194019\">+91-8367646436</a></span>\n  </mat-grid-tile>\n  <mat-grid-tile\n      [colspan]=\"2\"\n      [rowspan]=\"2\" style=\"background-color:lightblue\">\n    <iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3201.6348513672697!2d78.34397872266516!3d17.392247588609255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb945b30d855fd%3A0xe0c24e8ce5dd0821!2s7+Hills+Apartments!5e0!3m2!1sen!2sin!4v1533370869491\" height=\"400\" width=\"100%\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>\n  </mat-grid-tile>\n  <mat-grid-tile\n      [colspan]=\"1\"\n      [rowspan]=\"1\">\n    <span class=\"skype-button rectangle\" data-contact-id=\"binasen2015\"></span>\n    <script src=\"https://swc.cdn.skype.com/sdk/v1/sdk.min.js\"></script>\n  </mat-grid-tile>\n</mat-grid-list>\n      </mat-card-content>\n  </mat-card>\n</mat-card-content> \n</mat-card>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'sangeetshree';
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/material/toolbar */ "./node_modules/@angular/material/esm5/toolbar.es5.js");
/* harmony import */ var _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/grid-list */ "./node_modules/@angular/material/esm5/grid-list.es5.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatCardModule"],
                _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_3__["MatToolbarModule"],
                _angular_material_grid_list__WEBPACK_IMPORTED_MODULE_4__["MatGridListModule"]
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! hammerjs */ "./node_modules/hammerjs/hammer.js");
/* harmony import */ var hammerjs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(hammerjs__WEBPACK_IMPORTED_MODULE_4__);





if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! G:\dev\sangeetshree\nodeversion\sangeetshree\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map